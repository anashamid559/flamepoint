import classNames from "classnames";
import { Icons } from "../../assets";

const taskData = [
  {
    id: 1,
    image: Icons.Fires,
    altText: 'Fire',
    text: 'Post Any Task'
  },
  {
    id: 2,
    image: Icons.Fires,
    altText: 'Fire',
    text: 'Pick The Best Person'
  },
  {
    id: 3,
    image: Icons.Fires,
    altText: 'Fire',
    text: 'Get It Done!'
  }
];


const WorkData = [
  {
      title: 'Post A Job',
      description: 'Tell us what you need and we\'ll match you <br /> with qualified professionals.',
      imageSrc: Icons.Diary,
      text: 'Submit a Request'
  },
  {
      title: 'Hire A Pro',
      description: 'Review profiles, compare quotes, and hire <br /> the best fit for your project.',
      imageSrc: Icons.Search,
      text: 'Obtain an Instant Quote'
  },
  {
      title: 'Get The Job Done',
      description: 'Sit back and relax as your chosen pro <br /> completes the job to your satisfaction.',
      imageSrc: Icons.User,
      text: 'Purchase Suppliers'
  }
];



const quoteData = [
  {
    id: 1,
    image: Icons.Card,
    text: "Compare Quotes",
    altText: "Diary images",
    imgClassName: "card",
  },
  {
    id: 2,
    image: Icons.Hand,
    text: "Obtain Instant Quote",
    altText: "Gesture image",
    imgclassName: "hand",
  },
  {
    id: 3,
    image: Icons.Shower,
    text: "Purchase Equipment",
    altText: "Purchase image",
    imgclassName: "shower",
  }
];




const footerLinks = [
  {
    to: "/terms",
    label: "Terms & Conditions",
  },
  {
    to: "/privacy",
    label: "Privacy Policy",
  },
  {
    to: "/cookies",
    label: "Cookies",
  },
];




const linkData = [
  {
    section: 'Homeowners',
    links: [
      { text: 'Post a Request', to: '/post-request' },
      { text: 'My Account', to: '/my-account' },
      { text: 'Manage Requests', to: '/manage-requests' },
      { text: 'Contact Us', to: '/contact-us' },
    ],
  },
  {
    section: 'Supplier',
    links: [
      { text: 'Post a Request', to: '/post-request' },
      { text: 'My Account', to: '/my-account' },
      { text: 'Manage Requests', to: '/manage-requests' },
      { text: 'Contact Us', to: '/contact-us' },
    ],
  },
  {
    section: 'Company',
    links: [
      { text: 'Post a Request', to: '/post-request' },
      { text: 'My Account', to: '/my-account' },
      { text: 'Manage Requests', to: '/manage-requests' },
      { text: 'Contact Us', to: '/contact-us' },
    ],
  },
];


export {WorkData,taskData,quoteData,linkData,footerLinks }


