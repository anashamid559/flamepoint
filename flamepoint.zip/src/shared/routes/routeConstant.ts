const routeConstant = {
    home: {
      path: "/",
      title: "Home",
    },
  };
  
  export { routeConstant };
  