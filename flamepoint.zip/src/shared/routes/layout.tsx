import { useEffect } from "react";
import { useSelector } from "react-redux";
import { useLocation } from "react-router-dom";
//import DashboardWraper from "shared/components/common/dashboardWrapper";
//import Wrapper from "shared/components/common/wrapper";
import { routeConstant } from "./routeConstant";

interface LayoutProps {
  path: string;
  title: string;
  Component: any;
}

const Layout = ({ title, Component }: Partial<LayoutProps>) => {
  const {
    auth: { isLoggedIn },
  } = useSelector((state: any) => state.root);
  const location = useLocation();

  useEffect(() => {
    document.title = title + " | CGP";
    // eslint-disable-next-line
  });

  
};

export default Layout;
