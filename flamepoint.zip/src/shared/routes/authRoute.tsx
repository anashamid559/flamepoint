import React from "react";
import { Route, Routes, Navigate } from "react-router-dom";
import { publicRoute } from "./allRoutes";
import { routeConstant } from "./routeConstant";

// Define the RouteType interface
export interface RouteType {
  path: string;
  element: React.ComponentType; // React component type
}

const AuthRoute = () => {
  return (
    <Routes>
      {publicRoute.map((route: RouteType, index: number) => (
        <Route
          key={index}
          path={route.path}
          element={<route.element />}
        />
      ))}
      <Route
        path="*"
        element={<Navigate to={routeConstant.home.path} replace />}
      />
    </Routes>
  );
};

export default AuthRoute;
