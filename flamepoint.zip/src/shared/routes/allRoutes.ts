import Home from "../../pages";
import { routeConstant } from "./routeConstant";

// Define the RouteType interface to include 'element' instead of 'Component'
export interface RouteType {
  path: string;
  element: React.ComponentType; // React component type
}

const publicRoute: RouteType[] = [
  {
    path: routeConstant.home.path,
    element: Home, // Use 'element' instead of 'Component'
  },
];

export { publicRoute };
