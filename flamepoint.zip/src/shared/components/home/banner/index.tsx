import classNames from 'classnames';
import { Icons } from '../../../../assets';
import { taskData } from '../../../utils/constants';
import Button from '../../Button';
import styles from './style.module.scss';


const Section2 = () => {
    return (
        <section className={classNames(styles.background)}>
            <div className={classNames(styles.customContainer)}>
                <div className={classNames(styles.content, "flex flex-col items-center text-center")}>
                    <div className={classNames(styles.box)}>
                        <div className={classNames(styles.text, "flex flex-wrap")}>
                            {taskData.map(({ id, image, altText, text }) => (
                                <div key={id} className={classNames("flex gap-3")}>
                                    <img src={image} alt={altText} />
                                    <span>{text}</span>
                                </div>
                            ))}
                        </div>

                        <h1>
                            Fire Up <span>Your Sales</span> With More <br /> Business <span>Connections</span>
                        </h1>

                    </div>
                    <div className={classNames(styles.group, "flex")}>
                        <Button
                            imgSrc={Icons.Fire}
                            spanText="Post Your Request"
                            className={classNames(styles.post)}
                        />

                        <Button
                            imgSrc={Icons.Fires}
                            spanText="Become a Supplier"
                            className={classNames(styles.supply)}
                        />
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Section2;
