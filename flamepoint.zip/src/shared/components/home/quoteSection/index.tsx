import classNames from 'classnames';
import React from 'react';
import { Icons } from '../../../../assets';
import styles from './style.module.scss';

const sections = [
  {
    icon: Icons.Card,
    title: 'Compare Quotes',
    imgClass: styles.card,  
  },
  {
    icon: Icons.Hand,
    title: 'Obtain Instant Quote',
    imgClass: styles.hand, 
  },
  {
    icon: Icons.Shower,
    title: 'Purchase Equipment',
    imgClass: styles.shower, 
  },
];

const QuoteSection: React.FC = () => {
  return (
    <div className={classNames(styles.customContainer)}>
      <div className={classNames(styles.content, "flex-col md:flex-row")}>
        {sections.map((section, index) => (
          <div key={index} className={classNames(styles.box)}>
            <div className={classNames(styles.description)}>
              <img
                src={section.icon}
                alt={section.title}
                className={section.imgClass}
              />
            </div>
            <h1>{section.title}</h1>
          </div>
        ))}
      </div>
    </div>
  );
};

export default QuoteSection;
