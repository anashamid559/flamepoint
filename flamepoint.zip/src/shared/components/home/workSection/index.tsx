
import classNames from 'classnames';
import React from 'react';
import { Icons } from '../../../../assets';
import { WorkData } from '../../../utils/constants';
import Work from '../../work';
import styles from './style.module.scss';

const WorkSection: React.FC = () => {
    return (

        <section className={classNames(styles.work)}>
            <div className={classNames(styles.customContainer)}>
            <div className={classNames(styles.content,"flex flex-col items-center")}>
                    <div className={classNames(styles.description,"flex flex-col")}>
                        <div className={classNames(styles.text,"flex")}>
                            <img src={Icons.Fires} alt="Logo" />
                            <span>How We Work</span>
                        </div>
                         <h1>How Flame Point <span>Works</span></h1>
                    </div>
                    <div className={classNames(styles.box,"bg-none flex-col md:flex-row")}>
                        {WorkData.map((item, index) => (
                            <Work
                                key={index}
                                title={item.title}
                                description={item.description}
                                imageSrc={item.imageSrc}
                                text={item.text}
                            />
                        ))}
                    </div>
                </div>
            </div>
        </section>
    );
};

export default WorkSection;
