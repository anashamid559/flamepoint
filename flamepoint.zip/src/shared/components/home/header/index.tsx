import classNames from 'classnames';
import { Link } from 'react-router-dom';
import { Icons, Images } from '../../../../assets';
import useSideNav from '../../../hooks/useSidenav';
import Button from '../../Button';
import SideNav from '../../sidebarNav';
import styles from './style.module.scss';

const Section1 = () => {
    const { isSideNavOpen, toggleSideNav, closeSideNav, isLargeScreen } = useSideNav();

    const navLinks = [
        { to: '/', text: 'Home', className: styles.home },
        { to: '/services', text: 'Services' },
        { to: '/find-a-supplier', text: 'Find a Supplier' },
        { to: '/fire-safety-equipment', text: 'Fire Safety Equipment' },
        { to: '/about', text: 'About' },
        { to: '/contact', text: 'Contact' },
    ];

    return (
        <header className={classNames(styles.header, "sticky top-0")}>
            <div className={classNames(styles.customContainer)}>
                <nav className={classNames(styles.navContainer, "flex justify-between items-center")}>
                    <div className={classNames(styles.navbar, "flex items-center")}>
                        <div className={classNames(styles.hamburgerMenu, "flex lg:hidden")} onClick={toggleSideNav}>
                            ☰
                        </div>

                        <img src={Images.MaskGroup} alt="Mask Group" />

                        <ul className={classNames("lg:flex hidden ms-2")}>
                            {navLinks.map((link, index) => (
                                <li key={index}>
                                    <Link to={link.to}>
                                        {link.text}
                                    </Link>
                                </li>
                            ))}
                        </ul>
                    </div>

                    <div className={classNames(styles.navExtras, "flex items-center")}>
                        <div className={classNames(styles.authLink, "hidden sm:flex")}>
                            <button>Login /</button>
                            <button>Register</button>
                        </div>
                        <div className={classNames("hidden sm:flex")}>
                            <Button
                                imgSrc={Icons.Fire}
                                spanText="Get A quote"
                                className={classNames(styles.btn)}
                            />
                        </div>
                    </div>
                </nav>
                <SideNav isOpen={isSideNavOpen} onClose={closeSideNav} />
            </div>
        </header>
    );
};

export default Section1;
