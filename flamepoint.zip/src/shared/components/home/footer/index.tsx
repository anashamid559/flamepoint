import classNames from 'classnames';
import React from 'react';
import { Link } from 'react-router-dom';
import { Icons, Images } from '../../../../assets';
import { footerLinks, linkData } from '../../../utils/constants';
import styles from './style.module.scss';


const Footer = () => {
    return (
        <section className={classNames(styles.main)}>
            <div className={classNames(styles.customContainer)}>
                <div className={classNames(styles.border, "flex-col sm:flex-row gap-5")}>
                    <div className={classNames(styles.text)}>
                        <h1>Let’s keep in touch</h1>
                        <p>Sign up for Flame Point Newsletter and get all <br />
                            promotions and news to your inbox.</p>
                    </div>
                    <div className={classNames(styles.field,"flex flex-col")}>
                        <input type="email" placeholder="Email Address" name="" />
                        <div className={classNames(styles.line)}></div>
                    </div>
                </div>
                <div className={classNames(styles.big, "flex-col lg:flex-row gap-8")}>
                    <div className={classNames(styles.content, "flex flex-col lg:w-1/3")}>
                        <div className={classNames(styles.description)}>
                            <div className={classNames(styles.group,"flex flex-col")}>
                                <img src={Images.MaskGroup} alt="Mask Group" />
                                <p className={classNames(styles.para)}>Our platform connects homeowners with trusted  professionals, providing a seamless and efficient  solution for all your fire safety service needs.</p>
                            </div>
                        </div>
                        <div className={classNames(styles.icons)}>
                            <img src={Icons.Facebook} />
                            <img src={Icons.Twitter} />
                            <img src={Icons.Linkedin} />
                            <img src={Icons.Instagram} />
                        </div>
                    </div>
                    <div className={classNames(styles.list)}>
                        <div className={classNames(styles.text, "flex-col sm:flex-row gap-8")}>
                            {linkData.map((section, index) => (
                                <div
                                    key={index}
                                    className={classNames(styles.description, section.section === 'Supplier' && "text-wrap")}
                                >
                                    <div>
                                        <h3>For <span>{section.section}</span></h3>
                                    </div>
                                    <div className={classNames(styles.span)}>
                                        {section.links.map((link, idx) => (
                                            <Link key={idx} to={link.to} className={classNames(styles.links)}>{link.text}</Link>
                                        ))}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                <div className={classNames(styles.bottom, "flex-col md:flex-row")}>
                    <div className={classNames(styles.line)}></div>
                    <div className={classNames(styles.text)}>
                        <span>© 2024 Flame Point. All Rights Reserved.</span>
                        <div>
                            {footerLinks.map((link, index) => (
                                <React.Fragment key={index}>
                                    <Link to={link.to} className={classNames(styles.link)}>
                                        {link.label}
                                    </Link>
                                    {index < footerLinks.length - 1 && (
                                        <span> | </span>
                                    )}
                                </React.Fragment>
                            ))}
                        </div>
                    </div>
                </div>
            </div>

        </section >
    );
};

export default Footer;
