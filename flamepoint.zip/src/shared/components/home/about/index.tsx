import classNames from 'classnames';
import { Icons, Images } from '../../../../assets';
import ImageGrid from '../../imageGrid';
import styles from './style.module.scss';

const imageList = [
  Images.NFPA,
  Images.EDSB,
  Images.ACS,
  Images.EDSB,
  Images.Member,
  Images.ACS,
  Images.NFPA,
  Images.Member,
];

const About = () => {
  return (
    <section>
      <div className={classNames(styles.box, "pt-8")}>
        <div className={classNames(styles.customContainer)}>

          <div className={classNames(styles.content, "flex items-center")}>

            <h1>
              Our Vetted <span>Suppliers</span>
            </h1>
            <ImageGrid images={imageList} />
          </div>
        </div>
      </div>


      <div className={classNames(styles.main, "flex flex-col items-center")}>
        <div className={classNames(styles.customContainer)}>
          <div className={classNames(styles.description, "flex flex-col items-center")}>
            <div className={classNames(styles.text, "flex")}>
              <img src={Icons.Fires} alt="Logo" />
              <span>About Us</span>
            </div>
            <h1>
              About <span>Flame</span> Point
            </h1>
          </div>
          <div className={classNames(styles.paragragh)}>
            <p>
              If you’re looking for Supplier and companies to collaborate with, you’ll find them on Flame Point. We study what makes for <br /> a project successful, so finding each other is easy.
            </p>
            <p className={classNames('pt-8')}>
              If you’re looking for Supplier and companies to collaborate with, you’ll find them on Flame Point.
            </p>
          </div>
    
            {/* <Button
              imgSrc={Icons.Fire}
              spanText="Learn More"
              className={classNames(styles.btn)}
            /> */}
          </div>
        </div>
    </section >
  );
};

export default About;
