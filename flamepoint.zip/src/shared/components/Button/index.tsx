import React, { ButtonHTMLAttributes } from 'react';
import styles from "./style.module.scss";
import classNames from 'classnames';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  imgSrc?: string;
  imgAlt?: string;
  spanText?: string;
}

const customButton: React.FC<ButtonProps> = ({ imgSrc,spanText, className, ...rest }) => {
  return (
    <button className={classNames(styles.btn, className)} {...rest}>
      {imgSrc && <img src={imgSrc} />}
      {spanText && <span>{spanText}</span>}
    </button>
  );
};

export default customButton;
