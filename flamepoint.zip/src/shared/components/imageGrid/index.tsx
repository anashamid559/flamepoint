import classNames from 'classnames';
import React from 'react';
import styles from "./style.module.scss";

interface ImageGridProps {
  images: string[];
}

const ImageGrid: React.FC<ImageGridProps> = ({ images }) => {
  
  const imageElements = images.map((image) => (
    <img  
      src={image} 
    />
  ));

  return (
    <div className={classNames(styles.imageContainer,"flex items-center")}>
      {imageElements}
    </div>
  );
};

export default ImageGrid;
