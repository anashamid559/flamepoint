import classNames from 'classnames';
import React, { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Images } from '../../../assets';
import styles from "./style.module.scss";

interface SideNavProps {
    isOpen: boolean;
    onClose: () => void;
}

const navLinks = [
    { to: '/', text: 'Home', className: styles.home },
    { to: '/services', text: 'Services', className: styles.navLink },
    { to: '/find-a-supplier', text: 'Find a Supplier', className: styles.navLink },
    { to: '/fire-safety-equipment', text: 'Fire Safety Equipment', className: styles.navLink },
    { to: '/about', text: 'About', className: styles.navLink },
    { to: '/contact', text: 'Contact', className: styles.navLink },
];

const SideNav: React.FC<SideNavProps> = ({ isOpen, onClose }) => {
    const sideNavRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (sideNavRef.current && !sideNavRef.current.contains(event.target as Node)) {
                onClose();
            }
        };
        if (isOpen) {
            document.addEventListener('mousedown', handleClickOutside);
        }
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, [isOpen, onClose]);

    return (
        <div className={classNames(styles.sideNav, { [styles.open]: isOpen })} ref={sideNavRef}>
            <button className={styles.closeBtn} onClick={onClose}>×</button>

            <img src={Images.MaskGroup} alt="Mask Group" />

            <ul>
                {navLinks.map((link, index) => (
                    <li key={index}>
                        <Link to={link.to}>
                            {link.text}
                        </Link>
                    </li>
                ))}
            </ul>

            <div className={classNames(styles.authLink)}>
                <button>Login /</button>
                <button>Register</button>
            </div>
        </div>
    );
};

export default SideNav;
