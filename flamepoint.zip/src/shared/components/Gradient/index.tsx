import React from 'react';

const GradientComponent = () => {
  const gradientStyle = {
    height: '100vh', // Full height, adjust as needed
    width: '100%', // Full width, adjust as needed
    background: 'linear-gradient(#FAA93E, #EF4335)',
  };

  return <div style={gradientStyle}></div>;
};

export default GradientComponent;
