import classNames from 'classnames';
import parse from 'html-react-parser';
import React from 'react';
import { Icons } from '../../../assets';
import styles from './style.module.scss';


interface ShortCodeBoxProps {
    title: string;
    description: string;
    imageSrc: string;
    text: string;
}

const Work: React.FC<ShortCodeBoxProps> = ({ title, description, imageSrc, text }) => {
    return (
        <div className={classNames(styles.description,"flex flex-col items-center text-center")}>
            <img src={imageSrc} alt={title} className={classNames(styles.img)}/>

            <div className={classNames(styles.content,"flex flex-col items-center")}>
                <div className={classNames(styles.main,"flex flex-col")}>
                <h1>{title}</h1>
                <p>{parse(description)}</p>
                </div>
                <div className={classNames(styles.text)}>
                    <img src={Icons.Fires}  alt="Logo" />
                    <span>{text}</span>
                </div>
            </div>
        </div>
    );
};

export default Work;
