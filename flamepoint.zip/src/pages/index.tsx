import Section1 from "../shared/components/home/header";
import Section2 from "../shared/components/home/banner";
import About from "../shared/components/home/about";
import WorkSection from "../shared/components/home/workSection";
import QuoteSection from "../shared/components/home/quoteSection";
import Footer from "../shared/components/home/footer";

const Home = () => {
  return (
    <>
      <Section1 />
      <Section2 />
       <About />
      <WorkSection />
      <QuoteSection />
      <Footer /> 
      
    </>
  );
};

export default Home;
