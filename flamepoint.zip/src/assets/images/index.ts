import MaskGroup from "../images/logo.png";
import Background from "../images/Background.png";
import ACS from "../images/ACS.png";
import EDSB from "../images/EDSB.png";
import NFPA from "../images/fire.png";
import Member from "../images/member.png"




const Images = {
  MaskGroup,
  Background,
  ACS,
  EDSB,
  NFPA,
  Member,
};

export { Images };
