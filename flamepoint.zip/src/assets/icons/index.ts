

import Fire from "../icons/fire.svg";
import Fires from "../icons/fire2.svg"
import User from "../icons/user.svg";
import Search from "../icons/search.svg";
import Diary from "../icons/diary.svg";
import Card from "../icons/card.svg";
import Hand from "../icons/hand.svg";
import Shower from "../icons/shower.svg";
import Facebook from "../icons/facebook.svg";
import Twitter from "../icons/twitter.svg";
import Linkedin from "../icons/linkedin.svg";
import Instagram from "../icons/instagram.svg";
import Line from "../icons/line.svg";




const Icons = {
Fire,
Fires,
User,
Search,
Diary,
Card,
Hand,
Shower,
Facebook,
Twitter,
Linkedin,
Instagram,
};

export { Icons };